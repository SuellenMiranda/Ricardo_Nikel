const firebaseConfig = {
    apiKey: "AIzaSyAZjUq4N24vPM-rQ-rPvOQJPLpsSIJZ5VQ",
    authDomain: "trabricardo-dc4ee.firebaseapp.com",
    projectId: "trabricardo-dc4ee",
    storageBucket: "trabricardo-dc4ee.appspot.com",
    messagingSenderId: "404028404881",
    appId: "1:404028404881:web:9aed0b282b24d9edb77b30",
    measurementId: "G-C4FL313Z9B",
  };

  // Initialize Firebase
firebase.initializeApp(firebaseConfig);